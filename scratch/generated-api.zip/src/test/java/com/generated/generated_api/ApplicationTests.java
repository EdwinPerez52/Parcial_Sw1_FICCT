package com.generated.generated_api;

import com.generated.generated_api.auth.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
class ApplicationTests {

    @Autowired(required = false)
    private AuthService authService;

    @Autowired(required = false)
    private AuthUserRepository authUserRepository;

    @Test
    void contextLoads() {
        assertNotNull(authService, "AuthService debe estar inicializado en el contexto");
    }

    @Test
    void firstRegisteredUserIsAdmin() {
        if (authService == null || authUserRepository == null) return;
        authUserRepository.deleteAll();
        var first = authService.register(new AuthDtos.RegisterRequest("first_admin@example.com", "pass12345", "Primer Admin"));
        assertEquals(AuthRole.ROLE_ADMIN, first.user().role(), "El primer usuario debe ser ADMIN");

        var second = authService.register(new AuthDtos.RegisterRequest("second_user@example.com", "pass12345", "Segundo Usuario"));
        assertEquals(AuthRole.ROLE_USER, second.user().role(), "El segundo usuario debe ser USER");
    }
}
