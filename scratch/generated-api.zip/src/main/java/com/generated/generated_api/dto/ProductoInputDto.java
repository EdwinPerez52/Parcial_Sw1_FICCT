package com.generated.generated_api.dto;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;
import com.generated.generated_api.model.*;

public class ProductoInputDto {
    private BigDecimal precio;

    private Integer usuarioId;

    public BigDecimal getPrecio() { return precio; }
    public void setPrecio(BigDecimal value) { this.precio = value; }
    public Integer getUsuarioId() { return usuarioId; }
    public void setUsuarioId(Integer value) { this.usuarioId = value; }
}
