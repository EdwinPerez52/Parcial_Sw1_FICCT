package com.generated.generated_api.service;

import com.generated.generated_api.dto.ProductoInputDto;
import com.generated.generated_api.dto.ProductoOutputDto;
import com.generated.generated_api.error.ResourceNotFoundException;
import com.generated.generated_api.mapper.ProductoMapper;
import com.generated.generated_api.model.Producto;
import com.generated.generated_api.repository.ProductoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;

@Service
@Transactional
public class ProductoService {
    private final ProductoRepository repository;
    private final ProductoMapper mapper;

    public ProductoService(ProductoRepository repository, ProductoMapper mapper) {
        this.repository = repository;
        this.mapper = mapper;
    }

    @Transactional(readOnly = true)
    public List<ProductoOutputDto> findAll() {
        return repository.findAll().stream().map(mapper::toOutputDto).toList();
    }

    @Transactional(readOnly = true)
    public ProductoOutputDto findById(UUID id) {
        return repository.findById(id)
            .map(mapper::toOutputDto)
            .orElseThrow(() -> new ResourceNotFoundException("Producto no encontrado con id: " + id));
    }

    public ProductoOutputDto create(ProductoInputDto input) {
        Producto entity = mapper.toEntity(input);
        Producto saved = repository.save(entity);
        return mapper.toOutputDto(saved);
    }

    public ProductoOutputDto update(UUID id, ProductoInputDto input) {
        Producto entity = repository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Producto no encontrado con id: " + id));
        mapper.updateEntity(entity, input);
        Producto updated = repository.save(entity);
        return mapper.toOutputDto(updated);
    }

    public void deleteById(UUID id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Producto no encontrado con id: " + id);
        }
        repository.deleteById(id);
    }
}
