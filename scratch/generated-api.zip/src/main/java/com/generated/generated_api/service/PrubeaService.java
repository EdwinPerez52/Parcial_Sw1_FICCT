package com.generated.generated_api.service;

import com.generated.generated_api.dto.PrubeaInputDto;
import com.generated.generated_api.dto.PrubeaOutputDto;
import com.generated.generated_api.error.ResourceNotFoundException;
import com.generated.generated_api.mapper.PrubeaMapper;
import com.generated.generated_api.model.Prubea;
import com.generated.generated_api.repository.PrubeaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;

@Service
@Transactional
public class PrubeaService {
    private final PrubeaRepository repository;
    private final PrubeaMapper mapper;

    public PrubeaService(PrubeaRepository repository, PrubeaMapper mapper) {
        this.repository = repository;
        this.mapper = mapper;
    }

    @Transactional(readOnly = true)
    public List<PrubeaOutputDto> findAll() {
        return repository.findAll().stream().map(mapper::toOutputDto).toList();
    }

    @Transactional(readOnly = true)
    public PrubeaOutputDto findById(UUID id) {
        return repository.findById(id)
            .map(mapper::toOutputDto)
            .orElseThrow(() -> new ResourceNotFoundException("Prubea no encontrado con id: " + id));
    }

    public PrubeaOutputDto create(PrubeaInputDto input) {
        Prubea entity = mapper.toEntity(input);
        Prubea saved = repository.save(entity);
        return mapper.toOutputDto(saved);
    }

    public PrubeaOutputDto update(UUID id, PrubeaInputDto input) {
        Prubea entity = repository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Prubea no encontrado con id: " + id));
        mapper.updateEntity(entity, input);
        Prubea updated = repository.save(entity);
        return mapper.toOutputDto(updated);
    }

    public void deleteById(UUID id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Prubea no encontrado con id: " + id);
        }
        repository.deleteById(id);
    }
}
