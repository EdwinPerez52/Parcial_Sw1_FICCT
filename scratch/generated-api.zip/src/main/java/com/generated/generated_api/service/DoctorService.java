package com.generated.generated_api.service;

import com.generated.generated_api.dto.DoctorInputDto;
import com.generated.generated_api.dto.DoctorOutputDto;
import com.generated.generated_api.error.ResourceNotFoundException;
import com.generated.generated_api.mapper.DoctorMapper;
import com.generated.generated_api.model.Doctor;
import com.generated.generated_api.repository.DoctorRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;

@Service
@Transactional
public class DoctorService {
    private final DoctorRepository repository;
    private final DoctorMapper mapper;

    public DoctorService(DoctorRepository repository, DoctorMapper mapper) {
        this.repository = repository;
        this.mapper = mapper;
    }

    @Transactional(readOnly = true)
    public List<DoctorOutputDto> findAll() {
        return repository.findAll().stream().map(mapper::toOutputDto).toList();
    }

    @Transactional(readOnly = true)
    public DoctorOutputDto findById(UUID id) {
        return repository.findById(id)
            .map(mapper::toOutputDto)
            .orElseThrow(() -> new ResourceNotFoundException("Doctor no encontrado con id: " + id));
    }

    public DoctorOutputDto create(DoctorInputDto input) {
        Doctor entity = mapper.toEntity(input);
        Doctor saved = repository.save(entity);
        return mapper.toOutputDto(saved);
    }

    public DoctorOutputDto update(UUID id, DoctorInputDto input) {
        Doctor entity = repository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Doctor no encontrado con id: " + id));
        mapper.updateEntity(entity, input);
        Doctor updated = repository.save(entity);
        return mapper.toOutputDto(updated);
    }

    public void deleteById(UUID id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Doctor no encontrado con id: " + id);
        }
        repository.deleteById(id);
    }
}
