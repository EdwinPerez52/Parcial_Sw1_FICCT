package com.generated.generated_api.auth;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.*;

@Service
public class JwtService {
    private final String secret;
    private final long accessExpirationMs;
    private final long refreshExpirationMs;
    private final ObjectMapper mapper = new ObjectMapper();

    public JwtService(
        @Value("${app.jwt.secret:very-secret-jwt-key-for-development-purposes-only-32bytes}") String secret,
        @Value("${app.jwt.access-expiration-ms:3600000}") long accessExpirationMs,
        @Value("${app.jwt.refresh-expiration-ms:604800000}") long refreshExpirationMs
    ) {
        this.secret = secret;
        this.accessExpirationMs = accessExpirationMs;
        this.refreshExpirationMs = refreshExpirationMs;
    }

    public String generateAccessToken(AuthUser user) {
        return buildToken(user.getId().toString(), user.getEmail(), user.getRole().name(), user.getFullName(), accessExpirationMs);
    }

    public String generateRefreshToken(AuthUser user) {
        return buildToken(user.getId().toString(), user.getEmail(), user.getRole().name(), user.getFullName(), refreshExpirationMs);
    }

    public boolean validateToken(String token) {
        try {
            String[] parts = token.split("\\.");
            if (parts.length != 3) return false;
            String expectedSig = hmacSha256(parts[0] + "." + parts[1], secret);
            if (!MessageDigest.isEqual(parts[2].getBytes(StandardCharsets.UTF_8), expectedSig.getBytes(StandardCharsets.UTF_8))) {
                return false;
            }
            String payloadJson = new String(Base64.getUrlDecoder().decode(parts[1]), StandardCharsets.UTF_8);
            Map<?, ?> claims = mapper.readValue(payloadJson, Map.class);
            long exp = ((Number) claims.get("exp")).longValue();
            return Instant.now().getEpochSecond() < exp;
        } catch (Exception ex) {
            return false;
        }
    }

    public Map<String, Object> parseClaims(String token) {
        try {
            String[] parts = token.split("\\.");
            String payloadJson = new String(Base64.getUrlDecoder().decode(parts[1]), StandardCharsets.UTF_8);
            return mapper.readValue(payloadJson, Map.class);
        } catch (Exception ex) {
            throw new IllegalArgumentException("Token inválido", ex);
        }
    }

    public String extractEmail(String token) {
        return (String) parseClaims(token).get("email");
    }

    public String extractRole(String token) {
        return (String) parseClaims(token).get("role");
    }

    public String extractSubject(String token) {
        return (String) parseClaims(token).get("sub");
    }

    public long getRefreshExpirationMs() {
        return refreshExpirationMs;
    }

    private String buildToken(String sub, String email, String role, String fullName, long ttlMs) {
        try {
            String headerJson = "{\"alg\":\"HS256\",\"typ\":\"JWT\"}";
            long iat = Instant.now().getEpochSecond();
            long exp = Instant.now().plusMillis(ttlMs).getEpochSecond();

            Map<String, Object> payload = new LinkedHashMap<>();
            payload.put("sub", sub);
            payload.put("email", email);
            payload.put("role", role);
            payload.put("fullName", fullName);
            payload.put("iat", iat);
            payload.put("exp", exp);

            String encodedHeader = Base64.getUrlEncoder().withoutPadding().encodeToString(headerJson.getBytes(StandardCharsets.UTF_8));
            String encodedPayload = Base64.getUrlEncoder().withoutPadding().encodeToString(mapper.writeValueAsBytes(payload));
            String data = encodedHeader + "." + encodedPayload;
            String signature = hmacSha256(data, secret);
            return data + "." + signature;
        } catch (Exception ex) {
            throw new IllegalStateException("Error al generar token JWT", ex);
        }
    }

    private String hmacSha256(String data, String key) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        return Base64.getUrlEncoder().withoutPadding().encodeToString(mac.doFinal(data.getBytes(StandardCharsets.UTF_8)));
    }
}
