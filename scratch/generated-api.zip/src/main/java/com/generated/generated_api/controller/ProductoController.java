package com.generated.generated_api.controller;

import com.generated.generated_api.dto.ProductoInputDto;
import com.generated.generated_api.dto.ProductoOutputDto;
import com.generated.generated_api.service.ProductoService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;

@RestController
@RequestMapping("/api/producto")
public class ProductoController {
    private final ProductoService service;

    public ProductoController(ProductoService service) {
        this.service = service;
    }

    @GetMapping
    public List<ProductoOutputDto> findAll() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public ProductoOutputDto findById(@PathVariable UUID id) {
        return service.findById(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ProductoOutputDto create(@Valid @RequestBody ProductoInputDto input) {
        return service.create(input);
    }

    @PutMapping("/{id}")
    public ProductoOutputDto update(@PathVariable UUID id, @Valid @RequestBody ProductoInputDto input) {
        return service.update(id, input);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteById(@PathVariable UUID id) {
        service.deleteById(id);
    }
}
