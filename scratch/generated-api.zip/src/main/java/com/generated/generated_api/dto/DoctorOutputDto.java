package com.generated.generated_api.dto;

import java.math.BigDecimal;
import java.time.*;
import java.util.*;
import com.generated.generated_api.model.*;

public class DoctorOutputDto {
    private UUID id;
    private String profesion;
    private Integer usuarioId;

    public DoctorOutputDto() {}

    public UUID getId() { return id; }
    public void setId(UUID value) { this.id = value; }
    public String getProfesion() { return profesion; }
    public void setProfesion(String value) { this.profesion = value; }
    public Integer getUsuarioId() { return usuarioId; }
    public void setUsuarioId(Integer value) { this.usuarioId = value; }
}
