package com.generated.generated_api.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;

@Entity
@Table(name = "usuario")
@ModelElement("3b8ef457-c67c-413a-b147-ad37390859ab")
public class Usuario {
    @Id
    @ModelElement("bfaa1038-d950-44d9-9f55-1429df520553")
    @Column(name = "id", nullable = true, unique = true)
    private Integer id;

    @ModelElement("919dbaf2-8b25-4ced-8374-ba7f0ce8abf7")
    @Column(name = "nombre", nullable = true, unique = false)
    private String nombre;

    @ModelElement("f2f3e3b1-3e3b-4e78-9992-ef9ee9ceb412")
    @Column(name = "correo", nullable = true, unique = false)
    private String correo;

    @ModelElement("ee8a086c-10b3-416c-ad91-b739ac2ceb9c")
    @OneToMany(mappedBy = "usuario", cascade = CascadeType.ALL)
    private List<Doctor> doctors = new ArrayList<>();

    @ModelElement("feb3492b-cf4e-433d-84d9-22183d319e26")
    @OneToMany(mappedBy = "usuario", cascade = CascadeType.ALL)
    private List<Prubea> prubeas = new ArrayList<>();

    @ModelElement("c32d7e3b-5ae8-4108-862f-d57eed2da72c")
    @OneToMany(mappedBy = "usuario", cascade = CascadeType.ALL)
    private List<Producto> productos = new ArrayList<>();

    public Usuario() {}

    public Integer getId() { return id; }
    public void setId(Integer value) { this.id = value; }
    public String getNombre() { return nombre; }
    public void setNombre(String value) { this.nombre = value; }
    public String getCorreo() { return correo; }
    public void setCorreo(String value) { this.correo = value; }
    public List<Doctor> getDoctors() { return doctors; }
    public void setDoctors(List<Doctor> value) { this.doctors = value; }
    public List<Prubea> getPrubeas() { return prubeas; }
    public void setPrubeas(List<Prubea> value) { this.prubeas = value; }
    public List<Producto> getProductos() { return productos; }
    public void setProductos(List<Producto> value) { this.productos = value; }
}
