package com.generated.generated_api.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;

@Entity
@Table(name = "producto")
@ModelElement("053b47cc-8858-438c-9943-66bf60b07b77")
public class Producto {
    @Id
    @ModelElement("5f9a04a0-a6c4-460d-896d-541e485efac0")
    @Column(name = "id", nullable = false, unique = true)
    private UUID id;

    @ModelElement("718bc5ec-7612-44d5-938c-f67795e1b08d")
    @Column(name = "precio", nullable = true, unique = false)
    private BigDecimal precio;

    @ModelElement("c32d7e3b-5ae8-4108-862f-d57eed2da72c")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_id")
    private Usuario usuario;

    public Producto() {}

    public UUID getId() { return id; }
    public void setId(UUID value) { this.id = value; }
    public BigDecimal getPrecio() { return precio; }
    public void setPrecio(BigDecimal value) { this.precio = value; }
    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario value) { this.usuario = value; }
}
