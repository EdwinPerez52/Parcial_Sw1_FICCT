package com.generated.generated_api.controller;

import com.generated.generated_api.dto.UsuarioInputDto;
import com.generated.generated_api.dto.UsuarioOutputDto;
import com.generated.generated_api.service.UsuarioService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;

@RestController
@RequestMapping("/api/usuario")
public class UsuarioController {
    private final UsuarioService service;

    public UsuarioController(UsuarioService service) {
        this.service = service;
    }

    @GetMapping
    public List<UsuarioOutputDto> findAll() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public UsuarioOutputDto findById(@PathVariable Integer id) {
        return service.findById(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public UsuarioOutputDto create(@Valid @RequestBody UsuarioInputDto input) {
        return service.create(input);
    }

    @PutMapping("/{id}")
    public UsuarioOutputDto update(@PathVariable Integer id, @Valid @RequestBody UsuarioInputDto input) {
        return service.update(id, input);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteById(@PathVariable Integer id) {
        service.deleteById(id);
    }
}
