package com.generated.generated_api.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;

@Entity
@Table(name = "prubea")
@ModelElement("2303dc0b-367c-4856-9841-469fbad0ee97")
public class Prubea {
    @Id
    @ModelElement("384d930d-bda0-44a8-a1d4-0d22e0db96b5")
    @Column(name = "id", nullable = false, unique = true)
    private UUID id;

    @ModelElement("2beddc00-0a36-4e17-a933-cb03184e93b1")
    @Column(name = "h", nullable = true, unique = false)
    private String h;

    @ModelElement("14cc9128-3f09-41ca-9b0d-30b4c466d224")
    @Column(name = "sgsg", nullable = true, unique = false)
    private String sgsg;

    @ModelElement("feb3492b-cf4e-433d-84d9-22183d319e26")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_id")
    private Usuario usuario;

    public Prubea() {}

    public UUID getId() { return id; }
    public void setId(UUID value) { this.id = value; }
    public String getH() { return h; }
    public void setH(String value) { this.h = value; }
    public String getSgsg() { return sgsg; }
    public void setSgsg(String value) { this.sgsg = value; }
    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario value) { this.usuario = value; }
}
