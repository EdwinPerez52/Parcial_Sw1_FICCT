package com.generated.generated_api.controller;

import com.generated.generated_api.dto.DoctorInputDto;
import com.generated.generated_api.dto.DoctorOutputDto;
import com.generated.generated_api.service.DoctorService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;

@RestController
@RequestMapping("/api/doctor")
public class DoctorController {
    private final DoctorService service;

    public DoctorController(DoctorService service) {
        this.service = service;
    }

    @GetMapping
    public List<DoctorOutputDto> findAll() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public DoctorOutputDto findById(@PathVariable UUID id) {
        return service.findById(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public DoctorOutputDto create(@Valid @RequestBody DoctorInputDto input) {
        return service.create(input);
    }

    @PutMapping("/{id}")
    public DoctorOutputDto update(@PathVariable UUID id, @Valid @RequestBody DoctorInputDto input) {
        return service.update(id, input);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteById(@PathVariable UUID id) {
        service.deleteById(id);
    }
}
