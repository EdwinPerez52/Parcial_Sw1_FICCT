package com.generated.generated_api.dto;

import java.math.BigDecimal;
import java.time.*;
import java.util.*;
import com.generated.generated_api.model.*;

public class ProductoOutputDto {
    private UUID id;
    private BigDecimal precio;
    private Integer usuarioId;

    public ProductoOutputDto() {}

    public UUID getId() { return id; }
    public void setId(UUID value) { this.id = value; }
    public BigDecimal getPrecio() { return precio; }
    public void setPrecio(BigDecimal value) { this.precio = value; }
    public Integer getUsuarioId() { return usuarioId; }
    public void setUsuarioId(Integer value) { this.usuarioId = value; }
}
