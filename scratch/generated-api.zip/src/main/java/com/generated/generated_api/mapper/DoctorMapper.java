package com.generated.generated_api.mapper;

import com.generated.generated_api.dto.*;
import com.generated.generated_api.model.*;
import com.generated.generated_api.repository.*;
import org.springframework.stereotype.Component;
import java.util.*;

@Component
public class DoctorMapper {
    private final UsuarioRepository usuarioRepository;
    public DoctorMapper(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    public Doctor toEntity(DoctorInputDto dto) {
        Doctor entity = new Doctor();
        entity.setId(UUID.randomUUID());
        updateEntity(entity, dto);
        return entity;
    }

    public void updateEntity(Doctor entity, DoctorInputDto dto) {
        entity.setProfesion(dto.getProfesion());
        if (dto.getUsuarioId() != null) {
            entity.setUsuario(usuarioRepository.findById(dto.getUsuarioId()).orElse(null));
        } else { entity.setUsuario(null); }
    }

    public DoctorOutputDto toOutputDto(Doctor entity) {
        DoctorOutputDto dto = new DoctorOutputDto();
        dto.setId(entity.getId());
        dto.setProfesion(entity.getProfesion());
        if (entity.getUsuario() != null) {
            dto.setUsuarioId(entity.getUsuario().getId());
        }
        return dto;
    }
}
