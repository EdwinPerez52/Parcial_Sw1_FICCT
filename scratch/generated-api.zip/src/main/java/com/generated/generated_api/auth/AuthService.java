package com.generated.generated_api.auth;

import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.UUID;

@Service
@Transactional
public class AuthService {
    private final AuthUserRepository users;
    private final AuthTokenRepository tokens;
    private final JwtService jwt;
    private final PasswordEncoder passwordEncoder;

    public AuthService(
        AuthUserRepository users,
        AuthTokenRepository tokens,
        JwtService jwt,
        PasswordEncoder passwordEncoder
    ) {
        this.users = users;
        this.tokens = tokens;
        this.jwt = jwt;
        this.passwordEncoder = passwordEncoder;
    }

    public AuthDtos.TokenResponse register(AuthDtos.RegisterRequest request) {
        if (users.findByEmail(request.email().toLowerCase()).isPresent()) {
            throw new IllegalArgumentException("El correo ya se encuentra registrado: " + request.email());
        }
        // The first registered user gets ROLE_ADMIN, subsequent users get ROLE_USER
        AuthRole role = users.count() == 0 ? AuthRole.ROLE_ADMIN : AuthRole.ROLE_USER;
        AuthUser user = new AuthUser(
            UUID.randomUUID(),
            request.email().toLowerCase().trim(),
            passwordEncoder.encode(request.password()),
            request.fullName().trim(),
            role,
            Instant.now()
        );
        users.save(user);
        return createTokenResponse(user);
    }

    public AuthDtos.TokenResponse login(AuthDtos.LoginRequest request) {
        AuthUser user = users.findByEmail(request.email().toLowerCase().trim())
            .orElseThrow(() -> new BadCredentialsException("Credenciales inválidas"));
        if (!passwordEncoder.matches(request.password(), user.getPasswordHash())) {
            throw new BadCredentialsException("Credenciales inválidas");
        }
        return createTokenResponse(user);
    }

    public AuthDtos.TokenResponse refresh(AuthDtos.RefreshRequest request) {
        if (!jwt.validateToken(request.refreshToken())) {
            throw new BadCredentialsException("Token de refresco inválido o expirado");
        }
        AuthRefreshToken savedToken = tokens.findByTokenAndRevokedFalse(request.refreshToken())
            .orElseThrow(() -> new BadCredentialsException("Token de refresco revocado o no encontrado"));
        if (Instant.now().isAfter(savedToken.getExpiresAt())) {
            savedToken.setRevoked(true);
            tokens.save(savedToken);
            throw new BadCredentialsException("Token de refresco expirado");
        }
        AuthUser user = users.findById(savedToken.getUserId())
            .orElseThrow(() -> new BadCredentialsException("Usuario no encontrado"));

        String newAccess = jwt.generateAccessToken(user);
        return new AuthDtos.TokenResponse(
            newAccess,
            request.refreshToken(),
            "Bearer",
            new AuthDtos.UserResponse(user.getId(), user.getEmail(), user.getFullName(), user.getRole())
        );
    }

    public AuthDtos.UserResponse me(String email) {
        AuthUser user = users.findByEmail(email.toLowerCase())
            .orElseThrow(() -> new BadCredentialsException("Usuario no encontrado"));
        return new AuthDtos.UserResponse(user.getId(), user.getEmail(), user.getFullName(), user.getRole());
    }

    private AuthDtos.TokenResponse createTokenResponse(AuthUser user) {
        String accessToken = jwt.generateAccessToken(user);
        String refreshToken = jwt.generateRefreshToken(user);

        AuthRefreshToken tokenEntity = new AuthRefreshToken(
            UUID.randomUUID(),
            user.getId(),
            refreshToken,
            Instant.now().plusMillis(jwt.getRefreshExpirationMs()),
            false,
            Instant.now()
        );
        tokens.save(tokenEntity);

        return new AuthDtos.TokenResponse(
            accessToken,
            refreshToken,
            "Bearer",
            new AuthDtos.UserResponse(user.getId(), user.getEmail(), user.getFullName(), user.getRole())
        );
    }
}
