package com.generated.generated_api.repository;

import com.generated.generated_api.model.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import java.math.BigDecimal;
import java.time.*;
import java.util.UUID;

public interface ProductoRepository extends JpaRepository<Producto, UUID> {}
