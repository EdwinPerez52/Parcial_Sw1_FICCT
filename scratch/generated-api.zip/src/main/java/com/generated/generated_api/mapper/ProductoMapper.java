package com.generated.generated_api.mapper;

import com.generated.generated_api.dto.*;
import com.generated.generated_api.model.*;
import com.generated.generated_api.repository.*;
import org.springframework.stereotype.Component;
import java.util.*;

@Component
public class ProductoMapper {
    private final UsuarioRepository usuarioRepository;
    public ProductoMapper(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    public Producto toEntity(ProductoInputDto dto) {
        Producto entity = new Producto();
        entity.setId(UUID.randomUUID());
        updateEntity(entity, dto);
        return entity;
    }

    public void updateEntity(Producto entity, ProductoInputDto dto) {
        entity.setPrecio(dto.getPrecio());
        if (dto.getUsuarioId() != null) {
            entity.setUsuario(usuarioRepository.findById(dto.getUsuarioId()).orElse(null));
        } else { entity.setUsuario(null); }
    }

    public ProductoOutputDto toOutputDto(Producto entity) {
        ProductoOutputDto dto = new ProductoOutputDto();
        dto.setId(entity.getId());
        dto.setPrecio(entity.getPrecio());
        if (entity.getUsuario() != null) {
            dto.setUsuarioId(entity.getUsuario().getId());
        }
        return dto;
    }
}
