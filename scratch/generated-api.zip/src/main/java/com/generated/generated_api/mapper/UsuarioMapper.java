package com.generated.generated_api.mapper;

import com.generated.generated_api.dto.*;
import com.generated.generated_api.model.*;
import com.generated.generated_api.repository.*;
import org.springframework.stereotype.Component;
import java.util.*;

@Component
public class UsuarioMapper {
    private final DoctorRepository doctorRepository;
    private final PrubeaRepository prubeaRepository;
    private final ProductoRepository productoRepository;
    public UsuarioMapper(DoctorRepository doctorRepository, PrubeaRepository prubeaRepository, ProductoRepository productoRepository) {
        this.doctorRepository = doctorRepository;
        this.prubeaRepository = prubeaRepository;
        this.productoRepository = productoRepository;
    }

    public Usuario toEntity(UsuarioInputDto dto) {
        Usuario entity = new Usuario();
        updateEntity(entity, dto);
        return entity;
    }

    public void updateEntity(Usuario entity, UsuarioInputDto dto) {
        entity.setNombre(dto.getNombre());
        entity.setCorreo(dto.getCorreo());
    }

    public UsuarioOutputDto toOutputDto(Usuario entity) {
        UsuarioOutputDto dto = new UsuarioOutputDto();
        dto.setId(entity.getId());
        dto.setNombre(entity.getNombre());
        dto.setCorreo(entity.getCorreo());
        return dto;
    }
}
