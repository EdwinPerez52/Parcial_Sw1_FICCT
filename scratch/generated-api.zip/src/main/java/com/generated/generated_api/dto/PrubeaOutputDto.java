package com.generated.generated_api.dto;

import java.math.BigDecimal;
import java.time.*;
import java.util.*;
import com.generated.generated_api.model.*;

public class PrubeaOutputDto {
    private UUID id;
    private String h;
    private String sgsg;
    private Integer usuarioId;

    public PrubeaOutputDto() {}

    public UUID getId() { return id; }
    public void setId(UUID value) { this.id = value; }
    public String getH() { return h; }
    public void setH(String value) { this.h = value; }
    public String getSgsg() { return sgsg; }
    public void setSgsg(String value) { this.sgsg = value; }
    public Integer getUsuarioId() { return usuarioId; }
    public void setUsuarioId(Integer value) { this.usuarioId = value; }
}
