package com.generated.generated_api.controller;

import com.generated.generated_api.dto.PrubeaInputDto;
import com.generated.generated_api.dto.PrubeaOutputDto;
import com.generated.generated_api.service.PrubeaService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;

@RestController
@RequestMapping("/api/prubea")
public class PrubeaController {
    private final PrubeaService service;

    public PrubeaController(PrubeaService service) {
        this.service = service;
    }

    @GetMapping
    public List<PrubeaOutputDto> findAll() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public PrubeaOutputDto findById(@PathVariable UUID id) {
        return service.findById(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public PrubeaOutputDto create(@Valid @RequestBody PrubeaInputDto input) {
        return service.create(input);
    }

    @PutMapping("/{id}")
    public PrubeaOutputDto update(@PathVariable UUID id, @Valid @RequestBody PrubeaInputDto input) {
        return service.update(id, input);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteById(@PathVariable UUID id) {
        service.deleteById(id);
    }
}
