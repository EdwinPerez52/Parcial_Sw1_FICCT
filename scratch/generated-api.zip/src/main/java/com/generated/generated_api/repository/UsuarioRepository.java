package com.generated.generated_api.repository;

import com.generated.generated_api.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import java.math.BigDecimal;
import java.time.*;
import java.util.UUID;

public interface UsuarioRepository extends JpaRepository<Usuario, Integer> {}
