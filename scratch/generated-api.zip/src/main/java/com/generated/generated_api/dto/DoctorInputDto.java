package com.generated.generated_api.dto;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;
import com.generated.generated_api.model.*;

public class DoctorInputDto {
    @Size(max = 255)
    private String profesion;

    private Integer usuarioId;

    public String getProfesion() { return profesion; }
    public void setProfesion(String value) { this.profesion = value; }
    public Integer getUsuarioId() { return usuarioId; }
    public void setUsuarioId(Integer value) { this.usuarioId = value; }
}
