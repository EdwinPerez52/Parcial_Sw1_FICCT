package com.generated.generated_api.repository;

import com.generated.generated_api.model.Prubea;
import org.springframework.data.jpa.repository.JpaRepository;
import java.math.BigDecimal;
import java.time.*;
import java.util.UUID;

public interface PrubeaRepository extends JpaRepository<Prubea, UUID> {}
