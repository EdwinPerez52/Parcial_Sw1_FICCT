package com.generated.generated_api.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;

@Entity
@Table(name = "doctor")
@ModelElement("00ede02c-9916-4831-98c9-e40aefa04eed")
public class Doctor {
    @Id
    @ModelElement("ef239eed-8516-4403-a56d-c7e831c14134")
    @Column(name = "id", nullable = false, unique = true)
    private UUID id;

    @ModelElement("090add55-1619-4969-8790-151cd00eece3")
    @Column(name = "profesion", nullable = true, unique = false)
    private String profesion;

    @ModelElement("ee8a086c-10b3-416c-ad91-b739ac2ceb9c")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_id")
    private Usuario usuario;

    public Doctor() {}

    public UUID getId() { return id; }
    public void setId(UUID value) { this.id = value; }
    public String getProfesion() { return profesion; }
    public void setProfesion(String value) { this.profesion = value; }
    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario value) { this.usuario = value; }
}
