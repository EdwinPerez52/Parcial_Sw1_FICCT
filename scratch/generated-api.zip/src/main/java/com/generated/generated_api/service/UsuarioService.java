package com.generated.generated_api.service;

import com.generated.generated_api.dto.UsuarioInputDto;
import com.generated.generated_api.dto.UsuarioOutputDto;
import com.generated.generated_api.error.ResourceNotFoundException;
import com.generated.generated_api.mapper.UsuarioMapper;
import com.generated.generated_api.model.Usuario;
import com.generated.generated_api.repository.UsuarioRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;

@Service
@Transactional
public class UsuarioService {
    private final UsuarioRepository repository;
    private final UsuarioMapper mapper;

    public UsuarioService(UsuarioRepository repository, UsuarioMapper mapper) {
        this.repository = repository;
        this.mapper = mapper;
    }

    @Transactional(readOnly = true)
    public List<UsuarioOutputDto> findAll() {
        return repository.findAll().stream().map(mapper::toOutputDto).toList();
    }

    @Transactional(readOnly = true)
    public UsuarioOutputDto findById(Integer id) {
        return repository.findById(id)
            .map(mapper::toOutputDto)
            .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado con id: " + id));
    }

    public UsuarioOutputDto create(UsuarioInputDto input) {
        Usuario entity = mapper.toEntity(input);
        Usuario saved = repository.save(entity);
        return mapper.toOutputDto(saved);
    }

    public UsuarioOutputDto update(Integer id, UsuarioInputDto input) {
        Usuario entity = repository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado con id: " + id));
        mapper.updateEntity(entity, input);
        Usuario updated = repository.save(entity);
        return mapper.toOutputDto(updated);
    }

    public void deleteById(Integer id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Usuario no encontrado con id: " + id);
        }
        repository.deleteById(id);
    }
}
