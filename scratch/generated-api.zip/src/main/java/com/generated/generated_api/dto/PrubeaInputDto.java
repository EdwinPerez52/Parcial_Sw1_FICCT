package com.generated.generated_api.dto;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;
import com.generated.generated_api.model.*;

public class PrubeaInputDto {
    @Size(max = 255)
    private String h;

    @Size(max = 255)
    private String sgsg;

    private Integer usuarioId;

    public String getH() { return h; }
    public void setH(String value) { this.h = value; }
    public String getSgsg() { return sgsg; }
    public void setSgsg(String value) { this.sgsg = value; }
    public Integer getUsuarioId() { return usuarioId; }
    public void setUsuarioId(Integer value) { this.usuarioId = value; }
}
