package com.generated.generated_api.dto;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;
import com.generated.generated_api.model.*;

public class UsuarioInputDto {
    @Size(max = 255)
    private String nombre;

    @Size(max = 255)
    private String correo;

    public String getNombre() { return nombre; }
    public void setNombre(String value) { this.nombre = value; }
    public String getCorreo() { return correo; }
    public void setCorreo(String value) { this.correo = value; }
}
