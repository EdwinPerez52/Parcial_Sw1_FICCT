package com.generated.generated_api.mapper;

import com.generated.generated_api.dto.*;
import com.generated.generated_api.model.*;
import com.generated.generated_api.repository.*;
import org.springframework.stereotype.Component;
import java.util.*;

@Component
public class PrubeaMapper {
    private final UsuarioRepository usuarioRepository;
    public PrubeaMapper(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    public Prubea toEntity(PrubeaInputDto dto) {
        Prubea entity = new Prubea();
        entity.setId(UUID.randomUUID());
        updateEntity(entity, dto);
        return entity;
    }

    public void updateEntity(Prubea entity, PrubeaInputDto dto) {
        entity.setH(dto.getH());
        entity.setSgsg(dto.getSgsg());
        if (dto.getUsuarioId() != null) {
            entity.setUsuario(usuarioRepository.findById(dto.getUsuarioId()).orElse(null));
        } else { entity.setUsuario(null); }
    }

    public PrubeaOutputDto toOutputDto(Prubea entity) {
        PrubeaOutputDto dto = new PrubeaOutputDto();
        dto.setId(entity.getId());
        dto.setH(entity.getH());
        dto.setSgsg(entity.getSgsg());
        if (entity.getUsuario() != null) {
            dto.setUsuarioId(entity.getUsuario().getId());
        }
        return dto;
    }
}
