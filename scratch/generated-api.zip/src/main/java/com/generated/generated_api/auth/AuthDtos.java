package com.generated.generated_api.auth;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.util.UUID;

public class AuthDtos {
    public record RegisterRequest(
        @NotBlank @Email String email,
        @NotBlank @Size(min = 6) String password,
        @NotBlank String fullName
    ) {}

    public record LoginRequest(
        @NotBlank @Email String email,
        @NotBlank String password
    ) {}

    public record RefreshRequest(
        @NotBlank String refreshToken
    ) {}

    public record UserResponse(
        UUID id,
        String email,
        String fullName,
        AuthRole role
    ) {}

    public record TokenResponse(
        String accessToken,
        String refreshToken,
        String tokenType,
        UserResponse user
    ) {}
}
