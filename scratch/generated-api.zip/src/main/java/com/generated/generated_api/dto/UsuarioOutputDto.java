package com.generated.generated_api.dto;

import java.math.BigDecimal;
import java.time.*;
import java.util.*;
import com.generated.generated_api.model.*;

public class UsuarioOutputDto {
    private Integer id;
    private String nombre;
    private String correo;

    public UsuarioOutputDto() {}

    public Integer getId() { return id; }
    public void setId(Integer value) { this.id = value; }
    public String getNombre() { return nombre; }
    public void setNombre(String value) { this.nombre = value; }
    public String getCorreo() { return correo; }
    public void setCorreo(String value) { this.correo = value; }
}
