package com.generated.generated_api.auth;

public enum AuthRole {
    ROLE_ADMIN,
    ROLE_USER
}
